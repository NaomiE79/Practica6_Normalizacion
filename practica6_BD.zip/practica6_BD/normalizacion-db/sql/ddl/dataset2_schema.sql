-- Primero Productos y Facturas
CREATE TABLE IF NOT EXISTS Productos (
    StockCode VARCHAR(50) PRIMARY KEY,
    Descripcion TEXT
);

CREATE TABLE IF NOT EXISTS Facturas (
    InvoiceNo VARCHAR(50) PRIMARY KEY,
    InvoiceDate DATE,
    InvoiceHour TIME,
    CustomerID VARCHAR(50),
    Country VARCHAR(100)
);

-- Al final la tabla de detalle 
CREATE TABLE IF NOT EXISTS Detalle_Factura (
    InvoiceNo VARCHAR(50),
    StockCode VARCHAR(50),
    Quantity INT,
    UnitPrice DECIMAL(10, 2),
    PRIMARY KEY (InvoiceNo, StockCode),
    FOREIGN KEY (InvoiceNo) REFERENCES Facturas(InvoiceNo),
    FOREIGN KEY (StockCode) REFERENCES Productos(StockCode)
);


-- 1. Tabla Productos
--CREATE TABLE Productos (
  --  StockCode VARCHAR(50) PRIMARY KEY,
    --Description TEXT
--);

-- 2. Tabla Factura 
--CREATE TABLE Facturas (
  --  InvoiceNo VARCHAR(50) PRIMARY KEY,
    --InvoiceDate DATE,
    --InvoiceHour TIME,
    --CustomerID VARCHAR(50),
    --Country VARCHAR(100)
--);

-- 3. Tabla de DetalleVenta (Relación Factura-Producto)
--CREATE TABLE Detalle_Factura (
  --  InvoiceNo VARCHAR(50),
    --StockCode VARCHAR(50),
    --Quantity INT,
    --UnitPrice DECIMAL(10, 2),
    --PRIMARY KEY (InvoiceNo, StockCode),
    --FOREIGN KEY (InvoiceNo) REFERENCES Facturas(InvoiceNo),
    --FOREIGN KEY (StockCode) REFERENCES Productos(StockCode)
--);
