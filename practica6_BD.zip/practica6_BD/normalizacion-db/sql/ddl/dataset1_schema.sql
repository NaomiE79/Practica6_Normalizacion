-------------------------------IMPORTAR TABLA ORIGINAL-------------------------------
--COPY original FROM 'C:/Users/estra/Downloads/netflix_titles.csv' DELIMITER ',' CSV HEADER;

--------------------------------------------------------------------------------------
--------------------------------TABLA ORIGINAL----------------------------------------
--------------------------------------------------------------------------------------
--
--CREATE TABLE original (
  --  show_id VARCHAR(10),
    --type VARCHAR(50),
    --title VARCHAR(255),
    --director VARCHAR(255),
    --cast TEXT,
    --country VARCHAR(100),
   -- date_added DATE,
    --release_year INT,
    --rating VARCHAR(10),
    --duration VARCHAR(50),
    --listed_in TEXT,
  --  description TEXT
--);
--------------------
--------------------------------------------------------------------------------------
--------------------------------TABLAS NORMALIZADAS-----------------------------------
--------------------------------------------------------------------------------------

-- Tabla principal
CREATE TABLE shows (
    show_id VARCHAR(10) PRIMARY KEY,
    type VARCHAR(50),
    title VARCHAR(50),
    date_added DATE,
    release_year INT,
    rating VARCHAR(10),
    duration VARCHAR(50),
    description TEXT
);

-- Tabla de directores
CREATE TABLE directors (
    show_id VARCHAR(10),
    director VARCHAR(50),
    FOREIGN KEY (show_id) REFERENCES shows(show_id)
);

-- Tabla de actores(cast)
CREATE TABLE actores (
    show_id VARCHAR(10),
    actores VARCHAR(50),
    FOREIGN KEY (show_id) REFERENCES shows(show_id)
);

-- Tabla de países
CREATE TABLE countries (
    show_id VARCHAR(10),
    country VARCHAR(100),
    FOREIGN KEY (show_id) REFERENCES shows(show_id)
);

-- Tabla de categorías
CREATE TABLE categories (
    show_id VARCHAR(10),
    listed_in VARCHAR(100),
    FOREIGN KEY (show_id) REFERENCES shows(show_id)
);
