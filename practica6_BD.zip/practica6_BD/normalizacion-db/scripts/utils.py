# normalizacion-db/scripts/utils.py
import pandas as pd
import numpy as np
from sqlalchemy import create_engine
import os

# --- LECTURA Y LIMPIEZA ---

def cargar_datos(ruta_archivo, tipo_archivo='csv'):
    """Carga los datos desde un archivo (CSV, Excel, JSON)."""
    try:
        print(f"Cargando datos desde: {ruta_archivo}...")
        if tipo_archivo == 'csv':
            df = pd.read_csv(ruta_archivo)
        elif tipo_archivo == 'excel':
            df = pd.read_excel(ruta_archivo)
        elif tipo_archivo == 'json':
            df = pd.read_json(ruta_archivo)
        else:
            raise ValueError("Tipo de archivo no soportado.")

        print(f"Datos cargados. Filas: {len(df)}")
        return df

    except Exception as e:
        print(f"Error al cargar datos: {e}")
        return None

def limpiar_y_validar(df):
    """Maneja datos faltantes e inconsistentes (ejemplo básico)."""
    df_limpio = df.copy()
    
    # Rellenar faltantes en columnas de texto con 'N/A'
    for col in df_limpio.select_dtypes(include=['object']).columns:
        df_limpio[col] = df_limpio[col].fillna('N/A').astype(str)

    # Eliminar filas duplicadas idénticas
    df_limpio = df_limpio.drop_duplicates()
    
    print("Limpieza y validación básica completada.")
    return df_limpio

# --- PROCESO DE NORMALIZACIÓN (1FN, 2FN/3FN) ---

def aplicar_1fn(df, columnas_multivaluadas, separador=','):
    """Aplica la 1FN dividiendo columnas multivaluadas (uso de pandas.explode)."""
    df_1fn = df.copy()
    
    for col in columnas_multivaluadas:
        if col in df_1fn.columns:
            # Divide el string, luego 'explota' las filas
            df_1fn[col] = df_1fn[col].astype(str).str.split(separador).str.strip()
            df_1fn = df_1fn.explode(col)
            df_1fn[col] = df_1fn[col].str.strip() # Limpieza final

    print("Aplicada la Primera Forma Normal (1FN).")
    return df_1fn

def aplicar_2fn_3fn(df_1fn, esquema_tablas):
    """
    Aplica 2FN/3FN separando las columnas en tablas relacionadas y generando PKs.
    esquema_tablas: {'NombreTabla': ['PK_o_FK', 'Columna1', ...]}
    """
    tablas_normalizadas = {}
    
    # Generar un ID global si no existe
    df_procesado = df_1fn.copy()
    if 'ID_Unico_Global' not in df_procesado.columns:
         df_procesado.insert(0, 'ID_Unico_Global', range(1, len(df_procesado) + 1))

    for nombre_tabla, columnas in esquema_tablas.items():
        if not columnas:
            continue
            
        # 1. Seleccionar columnas para la tabla actual
        cols_a_seleccionar = [c for c in columnas if c in df_procesado.columns]
        df_secundaria = df_procesado[cols_a_seleccionar].copy()

        # 2. Manejo de Claves Primarias (PKs)
        pk_col = columnas[0]
        
        # Generar PK autoincremental si la PK es una columna nueva o si es tabla de lookup pura
        if not pk_col in df_secundaria.columns or len(df_secundaria[pk_col].unique()) == len(df_secundaria):
             # Para tablas lookup o cuando se necesita una PK simple
             df_secundaria = df_secundaria.drop_duplicates()
             df_secundaria.insert(0, f"PK_{nombre_tabla}", range(1, len(df_secundaria) + 1))
        
        # Eliminar duplicados después de la selección de columnas para 2FN/3FN
        df_secundaria = df_secundaria.drop_duplicates().reset_index(drop=True)
        tablas_normalizadas[nombre_tabla] = df_secundaria
    
    print(f"Generadas {len(tablas_normalizadas)} tablas normalizadas.")
    return tablas_normalizadas

###################################### EXPORTACIÓN DE RESULTADOS #################################

def exportar_sql(tablas_normalizadas, output_dir, db_name='base_normalizada', tipo_db='sqlite'):
    """
    Exporta a scripts DDL/DML y a una base de datos SQLite.
    """
    # 1. Configuración de Rutas
    ddl_dir = os.path.join(output_dir, 'sql', 'ddl')
    dml_dir = os.path.join(output_dir, 'sql', 'dml')
    os.makedirs(ddl_dir, exist_ok=True)
    os.makedirs(dml_dir, exist_ok=True)
    
    # 2. Generar DDL/DML (función auxiliar simplificada)
    ddl_script = f"-- Script DDL para {db_name}\n\n"
    dml_script = f"-- Script DML para {db_name}\n\n"
    
    tipo_sql = {'object': 'VARCHAR(255)', 'int64': 'INTEGER', 'float64': 'REAL'}

    for nombre_tabla, df in tablas_normalizadas.items():
        # Generación de DDL (Creación de tabla)
        columnas_ddl = []
        pk_columna = df.columns[0] # Asumiendo PK en la primera columna
        
        for col in df.columns:
            tipo_pandas = df[col].dtype.name
            tipo_final = tipo_sql.get(tipo_pandas, 'VARCHAR(255)')
            col_ddl = f"    {col} {tipo_final}"
            if col == pk_columna and 'PK_' in pk_columna: # Marcar solo PKs generadas
                col_ddl += " PRIMARY KEY"
            columnas_ddl.append(col_ddl)
        
        ddl_script += f"CREATE TABLE {nombre_tabla} (\n" + ",\n".join(columnas_ddl) + "\n);\n\n"

        # Generación de DML (Inserción de datos - simplificado)
        dml_script += f"INSERT INTO {nombre_tabla} ({', '.join(df.columns)}) VALUES\n"
        valores_insert = []
        for index, row in df.iterrows():
            valores_insert.append(f"({', '.join([f"'{str(x).replace("'", "''")}'" if pd.api.types.is_string_dtype(type(x)) else str(x) for x in row.values])})")
        
        dml_script += ",\n".join(valores_insert) + ";\n\n"
        
    # 3. Guardar DDL y DML
    with open(os.path.join(ddl_dir, f'{db_name}_schema.sql'), "w") as f:
        f.write(ddl_script)
    with open(os.path.join(dml_dir, f'{db_name}_data.sql'), "w") as f:
        f.write(dml_script)
    print(f"Scripts DDL y DML guardados en {ddl_dir} y {dml_dir}.")


def exportar_csv_y_db(tablas_normalizadas, output_dir, dataset_name):
    """
    Exporta a CSV separados y a la base de datos (SQLite por defecto).
    """
    # Rutas
    csv_dir = os.path.join(output_dir, 'data', 'normalized', dataset_name)
    os.makedirs(csv_dir, exist_ok=True)
    
    db_path = os.path.join(output_dir, 'data', 'normalized', f'{dataset_name}.db')
    engine = create_engine(f'sqlite:///{db_path}')

    print(f"\nExportando tablas para {dataset_name}...")
    
    with engine.connect() as connection:
        for nombre_tabla, df in tablas_normalizadas.items():
            # Exportar a CSV
            csv_ruta = os.path.join(csv_dir, f"{nombre_tabla}.csv")
            df.to_csv(csv_ruta, index=False)
            print(f"- Exportado CSV: {nombre_tabla}.csv")
            
            # Exportar a SQLite
            df.to_sql(nombre_tabla, connection, if_exists='replace', index=False)
            print(f"- Exportado a DB: Tabla '{nombre_tabla}'")