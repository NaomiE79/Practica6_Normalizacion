import pandas as pd
import os

def normalize_netflix():
    # Rutas de entrada y salida
    input_path = 'data/raw/dataset1.csv'
    sql_output = 'sql/dml/dataset1_data.sql'
    csv_output_dir = 'data/normalized/dataset1/'
    
    # Crear carpeta de salida si no existe
    os.makedirs(csv_output_dir, exist_ok=True)
    
    # Leer el archivo original
    df = pd.read_csv(input_path)

    # --- 1. PROCESAMIENTO Y EXPORTACIÓN A CSV ---
    
    # Tabla Catálogo (Quitamos las columnas que vamos a normalizar)
    catalogo = df[['show_id', 'type', 'title', 'release_year', 'rating', 'duration', 'description']].copy()
    catalogo.to_csv(os.path.join(csv_output_dir, 'catalogo.csv'), index=False)

    # Listas para almacenar entidades únicas
    directores_list = []
    actores_list = []
    
    # Relaciones para CSV (para que sepas qué actor sale en qué serie)
    rel_directores = []
    rel_actores = []

    for _, row in df.iterrows():
        sid = row['show_id']
        
        # Procesar Directores
        if pd.notna(row['director']):
            for d in row['director'].split(','):
                name = d.strip()
                directores_list.append(name)
                rel_directores.append({'show_id': sid, 'director': name})
        
        # Procesar Actores
        if pd.notna(row['cast']):
            for a in row['cast'].split(','):
                name = a.strip()
                actores_list.append(name)
                rel_actores.append({'show_id': sid, 'actor': name})

    # Guardar archivos CSV normalizados
    pd.DataFrame(sorted(list(set(directores_list))), columns=['name']).to_csv(os.path.join(csv_output_dir, 'directores_unicos.csv'), index=False)
    pd.DataFrame(sorted(list(set(actores_list))), columns=['name']).to_csv(os.path.join(csv_output_dir, 'actores_unicos.csv'), index=False)
    pd.DataFrame(rel_directores).to_csv(os.path.join(csv_output_dir, 'relacion_directores.csv'), index=False)
    pd.DataFrame(rel_actores).to_csv(os.path.join(csv_output_dir, 'relacion_actores.csv'), index=False)

    print(f"✅ Archivos CSV de Netflix guardados en: {csv_output_dir}")

    # --- 2. GENERACIÓN DE SQL (DML) ---
    
    with open(sql_output, 'w', encoding='utf-8') as f:
        f.write("SET session_replication_role = 'replica';\n\n")

        # Inserts de Catálogo
        for _, row in catalogo.iterrows():
            title = str(row['title']).replace("'", "''")
            desc = str(row['description']).replace("'", "''")
            f.write(f"INSERT INTO Catalogo (show_id, type, title, release_year, rating, duration, description) "
                    f"VALUES ('{row['show_id']}', '{row['type']}', '{title}', {row['release_year']}, '{row['rating']}', '{row['duration']}', '{desc}');\n")

        # Inserts de Directores (usando el set para no repetir)
        for d in sorted(list(set(directores_list))):
            name = d.replace("'", "''")
            f.write(f"INSERT INTO Directores (name) VALUES ('{name}') ON CONFLICT (name) DO NOTHING;\n")

        # Inserts de Actores
        for a in sorted(list(set(actores_list))):
            name = a.replace("'", "''")
            f.write(f"INSERT INTO Actores (name) VALUES ('{name}') ON CONFLICT (name) DO NOTHING;\n")

        f.write("\nSET session_replication_role = 'origin';\n")
    
    print(f"✅ SQL para Netflix generado en: {sql_output}")

if __name__ == "__main__":
    normalize_netflix()