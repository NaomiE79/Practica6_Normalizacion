import pandas as pd
import os

def normalize_dataset2():
    # Rutas de carpetas
    input_path = 'data/raw/dataset2.csv'
    sql_output = 'sql/dml/dataset2_data.sql'
    csv_output_dir = 'data/normalized/dataset2/'

    # Crear la carpeta de destino si no existe
    os.makedirs(csv_output_dir, exist_ok=True)
    
    print(f"Leyendo {input_path}...")
    
    try:
        # Leemos con latin1 para evitar el error del símbolo de Libra (£)
        df = pd.read_csv(input_path, encoding='latin1')
    except Exception as e:
        df = pd.read_csv(input_path, encoding='ISO-8859-1')

    # --- LIMPIEZA INICIAL ---
    df.columns = df.columns.str.strip()
    df['InvoiceDate'] = pd.to_datetime(df['InvoiceDate'])
    df['only_date'] = df['InvoiceDate'].dt.date
    df['only_hour'] = df['InvoiceDate'].dt.time
    df['CustomerID'] = df['CustomerID'].fillna('00000').astype(str)
    df['Description'] = df['Description'].fillna('SIN DESCRIPCION').str.replace("'", "''")

    # --- GENERAR LOS 3 CSVs SEPARADOS ---
    
    # 1. CSV de Productos
    productos_df = df[['StockCode', 'Description']].drop_duplicates('StockCode')
    productos_df.to_csv(os.path.join(csv_output_dir, 'productos.csv'), index=False, encoding='utf-8')
    
    # 2. CSV de Facturas
    facturas_df = df[['InvoiceNo', 'only_date', 'only_hour', 'CustomerID', 'Country']].drop_duplicates('InvoiceNo')
    facturas_df.to_csv(os.path.join(csv_output_dir, 'facturas.csv'), index=False, encoding='utf-8')
    
    # 3. CSV de Detalle de Venta
    detalle_df = df[['InvoiceNo', 'StockCode', 'Quantity', 'UnitPrice']]
    detalle_df.to_csv(os.path.join(csv_output_dir, 'detalle_venta.csv'), index=False, encoding='utf-8')

    print(f"✅ Se han creado 3 CSVs en: {csv_output_dir}")

    # --- GENERAR SQL DML (Igual que antes) ---
    with open(sql_output, 'w', encoding='utf-8') as f:
        f.write("SET session_replication_role = 'replica';\n\n")

        # SQL Productos
        for _, row in productos_df.iterrows():
            f.write(f"INSERT INTO Productos (StockCode, Description) VALUES ('{row['StockCode']}', '{row['Description']}') ON CONFLICT (StockCode) DO NOTHING;\n")

        # SQL Facturas
        for _, row in facturas_df.iterrows():
            f.write(f"INSERT INTO Facturas (InvoiceNo, InvoiceDate, InvoiceHour, CustomerID, Country) "
                    f"VALUES ('{row['InvoiceNo']}', '{row['only_date']}', '{row['only_hour']}', '{row['CustomerID']}', '{row['Country']}') ON CONFLICT (InvoiceNo) DO NOTHING;\n")

        # SQL Detalles
        for _, row in detalle_df.iterrows():
            f.write(f"INSERT INTO Detalle_Factura (InvoiceNo, StockCode, Quantity, UnitPrice) "
                    f"VALUES ('{row['InvoiceNo']}', '{row['StockCode']}', {row['Quantity']}, {row['UnitPrice']});\n")

        f.write("\nSET session_replication_role = 'origin';\n")
    
    print(f"✅ Archivo SQL actualizado.")

if __name__ == "__main__":
    normalize_dataset2()